/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest.classes;

/**
 *
 * @author giannis21
 */
public class results_by_date {
    String ekskentro_name,date,name,username,question,answer,correct,true_false;

    public results_by_date(String ekskentro_name, String date, String name, String username, String question, String answer, String correct, String true_false) {
        this.ekskentro_name = ekskentro_name;
        this.date = date;
        this.name = name;
        this.username = username;
        this.question = question;
        this.answer = answer;
        this.correct = correct;
        this.true_false = true_false;
    }

    public String getEkskentro_name() {
        return ekskentro_name;
    }

    public String getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrect() {
        return correct;
    }

    public String getTrue_false() {
        return true_false;
    }
    
}
