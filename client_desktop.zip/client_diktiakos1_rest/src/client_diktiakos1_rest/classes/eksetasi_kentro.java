/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest.classes;

/**
 *
 * @author giannis21
 */
public class eksetasi_kentro {
     
   String code,date,time,name,address;

    public eksetasi_kentro(String code, String date, String time, String name, String address) {
        this.code = code;
        this.date = date;
        this.time = time;
        this.name = name;
        this.address = address;
    }



    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
 
}
