/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest.classes;

/**
 *
 * @author giannis21
 */
public class result_by_choice {
    String name,username,question,answer,correct,time,true_false;

    public result_by_choice(String name, String username, String question, String answer, String correct, String time, String true_false) {
        this.name = name;
        this.username = username;
        this.question = question;
        this.answer = answer;
        this.correct = correct;
        this.time = time;
        this.true_false = true_false;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrect() {
        return correct;
    }

    public String getTime() {
        return time;
    }

    public String getTrue_false() {
        return true_false;
    }
    
}
