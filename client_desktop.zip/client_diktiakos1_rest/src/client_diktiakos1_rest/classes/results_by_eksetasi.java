/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest.classes;

/**
 *
 * @author giannis21
 */
public class results_by_eksetasi {
    String eksetasi_code,date,eksetasi_time,name,username,question,answer,correct,true_false;

    public results_by_eksetasi(String eksetasi_code, String date, String eksetasi_time, String name, String username, String question, String answer, String correct, String true_false) {
        this.eksetasi_code = eksetasi_code;
        this.date = date;
        this.eksetasi_time = eksetasi_time;
        this.name = name;
        this.username = username;
        this.question = question;
        this.answer = answer;
        this.correct = correct;
        this.true_false = true_false;
    }

    public String getEksetasi_code() {
        return eksetasi_code;
    }

    public String getDate() {
        return date;
    }

    public String getEksetasi_time() {
        return eksetasi_time;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrect() {
        return correct;
    }

    public String getTrue_false() {
        return true_false;
    }

   
  
    
}
