/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest.classes;

/**
 *
 * @author giannis21
 */
public class results_ana_kodiko {
   String code,name,username,question,answer,correct,true_false;

    public results_ana_kodiko(String code, String name, String username, String question, String answer, String correct, String true_false) {
        this.code = code;
        this.name = name;
        this.username = username;
        this.question = question;
        this.answer = answer;
        this.correct = correct;
        this.true_false = true_false;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrect() {
        return correct;
    }

    public String getTrue_false() {
        return true_false;
    }
   
   
}
