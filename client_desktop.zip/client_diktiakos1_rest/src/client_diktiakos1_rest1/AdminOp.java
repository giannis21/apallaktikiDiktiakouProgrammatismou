package client_diktiakos1_rest1;

import client_diktiakos1_rest.classes.eksetasi;
import client_diktiakos1_rest.classes.eksetasi_kentro;
import client_diktiakos1_rest.classes.el_eksetazomenou;
import client_diktiakos1_rest.classes.kentro;
import client_diktiakos1_rest.classes.result_by_choice;
import client_diktiakos1_rest.classes.results_ana_kodiko;
import client_diktiakos1_rest.classes.results_by_date;
import client_diktiakos1_rest.classes.results_by_eksetasi;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AdminOp extends javax.swing.JFrame implements ActionListener {
    final static String BUTTONPANEL = "Tab with JButtons";
    final static String TEXTPANEL = "Tab with JTextField";
  
    final static int extraWindowWidth = 1200;
    final static int extraWindowHeight = 300;
      JTextField txt_name,txt_username,txt_password,txt_erot,txt_ans1,txt_ans2,txt_ans3,txt_ans4,txt_addr,txt_name_kentrou,txt_date,txt_time,txt_username_admin,txt_password_admin;
     JComboBox comb ,comb1,comb2,comb3;
     JRadioButton radio1,radio2,radio3,radio4;
     ArrayList<JCheckBox> box,JCheckBox1;
    
    private Panel cardpanel;
    private CardLayout mycard;

    public void addComponentToPane(Container pane) {
        try {
            JTabbedPane tabbedPane = new JTabbedPane();
            tabbedPane.setFont( new Font( "Dialog", Font.PLAIN|Font.PLAIN, 15 ) ); //εχει να κανει με τις καρτελες
            //Create the "cards".
            JPanel card1 = new JPanel() {
                //Make the panel wider than it really needs, so
                //the window's wide enough for the tabs to stay
                //in one row.
                public Dimension getPreferredSize() {
                    Dimension size = super.getPreferredSize();
                    size.width += extraWindowWidth;
                    size.height+=extraWindowHeight;
                    return size;  
                }
            };  
               tabbedPane.addChangeListener(new ChangeListener() {
 
                   @Override
                   public void stateChanged(ChangeEvent e) {
                       if (e.getSource() instanceof JTabbedPane) {
                           JTabbedPane pane = (JTabbedPane) e.getSource();
                           
                           pane.getComponentAt(pane.getSelectedIndex());
                       //    JPanel panel = (JPanel)pane.getSelectedComponent();
                        //    panel.invalidate();
                           // panel.removeAll();
                           //kentro=3
                           
                           ///////////////////////////////////////////////////////////
                           
                           
                           
                           
                           
                           
                           
                           
                           
                           
                           
                     //      pane.revalidate();
                     //      pane.updateUI();
                     //      pane.repaint();
                           System.out.println("Selected paneNo : " + pane.getSelectedIndex());
                       }
                   }
               });
            Font font1 = new Font("SansSerif", Font.BOLD, 30);
            Font font2 = new Font("SansSerif", Font.BOLD, 20);
            Font font3 = new Font("SansSerif", Font.PLAIN, 16);
            Font font4 = new Font("SansSerif", Font.PLAIN, 20);
            JLabel l0=new JLabel("Εξεταζόμενος");
            l0.setFont(font1);
            JLabel Name=new JLabel("Όνομα");
            Name.setFont(font1);
            txt_name=new JTextField("",15); //το 15 ειναι το μεγεθος
            txt_name.setFont(font4);
            
            
            JLabel username=new JLabel("Συνθηματικό");
            username.setFont(font1);
            txt_username=new JTextField("",15);
            txt_username.setFont(font4);
            
            
            JLabel password=new JLabel("Κωδικός");
            password.setFont(font1);
            txt_password=new JTextField("",15);
            txt_password.setFont(font4);
            
            
            JLabel ekset=new JLabel("Εξέταση");
            ekset.setFont(font1);
            
            
            JButton insert_btn=new JButton("Καταχώρηση");
            insert_btn.setFont(font1);
            insert_btn.addActionListener(this);
            ArrayList ar_eksetasis=new ArrayList();
            comb = new JComboBox();
            
            
            URL url = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetasis");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);
            String output,result2="";
            while ((output = br.readLine()) != null) 
            {
                result2+=output;
            }
            
            
            JSONArray arr = new JSONArray(result2); //μετατρεπει το result2 που ειναι string se json array
            for (int i = 0; i < arr.length(); i++)
            { 
                JSONObject obj = arr.getJSONObject(i);   //περνει το καθε αντικειμενο json π υπαρχει στον πινακα
                String code = obj.getString("code");
                String date = obj.getString("date");
                String time = obj.getString("time");
                
                eksetasi k=new eksetasi(code,date,time);
                ar_eksetasis.add(k); 
            }
            for(int p=0;p<ar_eksetasis.size();p++)   
            {
                eksetasi k=(eksetasi)ar_eksetasis.get(p);     //αυτα που πηρα απο το json τα παιρνω μεσω της λιστας που χρησιμοποιησα
                
                comb.addItem(k.getCode()+"-"+k.getDate()+"-"+k.getTime()); //και τα βαζω σε combobox

            }
            comb.setFont(font3);
            comb.addActionListener(this);
            
            
            Box box = new Box(BoxLayout.Y_AXIS);            //οριζω ενα κουτι στο οποιο θα βαλω ολα τα στοιχεια για να τα μετατοπισω στο κεντρο
            l0.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            Name.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_name.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            username.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_username.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            password.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_password.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            comb.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            insert_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            ekset.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            
            
            box.add( l0 );
            box.add( Box.createVerticalStrut(12) );  //καθετο υψος 12 πιξελς
            box.add( Name );
            box.add( Box.createVerticalStrut(12) );
            box.add( txt_name );
            box.add( username );
            box.add( Box.createVerticalStrut(12) );
            box.add( txt_username );
            box.add( password );
            box.add( Box.createVerticalStrut(12) );
            box.add( txt_password );
            box.add( Box.createVerticalStrut(12) );
            box.add( ekset );
            box.add( comb );
            box.add( Box.createVerticalStrut(12) );
            box.add( insert_btn );
            card1.add(box);
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            
            JLabel erot=new JLabel("Ερώτηση"); 
            erot.setFont(font1);
            txt_erot=new JTextField("",15);
            txt_erot.setFont(font4);

            JLabel ans1=new JLabel("Απάντηση-1");
            ans1.setFont(font1);
            txt_ans1=new JTextField("",15);
            txt_ans1.setFont(font4);



            JLabel ans2=new JLabel("Απάντηση-2");
            ans2.setFont(font1);
            txt_ans2=new JTextField("",15);
            txt_ans2.setFont(font4);

            JLabel ans3=new JLabel("Απάντηση-3");
            ans3.setFont(font1);
            txt_ans3=new JTextField("",15);
            txt_ans3.setFont(font4);

            JLabel ans4=new JLabel("Απάντηση-4");
            ans4.setFont(font1);
            txt_ans4=new JTextField("",15);
            txt_ans4.setFont(font4);


            JLabel cor=new JLabel("Σωστή");
            cor.setFont(font1);
            JButton insert_erot_btn=new JButton("Καταχώρηση ερωτήσεων");
            insert_erot_btn.setFont(font1);
            insert_erot_btn.addActionListener(this);

            radio1 = new JRadioButton("1");
            radio1.setSelected(true);
            radio2 = new JRadioButton("2");
            radio3 = new JRadioButton("3");
            radio4 = new JRadioButton("4");

            ButtonGroup group = new ButtonGroup();    //βαζω τα radios se button group ωστε να μπορεσω να παρω το selected item
            group.add(radio1);
            group.add(radio2);
            group.add(radio3);
            group.add(radio4);
                                  
     
       
            Box box1 = new Box(BoxLayout.Y_AXIS);

            erot.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_erot.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            ans1.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_ans1.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            ans2.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_ans2.setAlignmentX(JComponent.CENTER_ALIGNMENT);
          //  comb.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            ans3.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_ans3.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            ans4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            txt_ans4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            cor.setAlignmentX(JComponent.CENTER_ALIGNMENT);

            radio1.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            radio2.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            radio3.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            radio4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
            insert_erot_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);

            box1.add( erot );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( txt_erot );

            box1.add( ans1 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( txt_ans1 );

            box1.add( ans2 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( txt_ans2 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( ans3 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( txt_ans3 );
            box1.add( ans4 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( txt_ans4 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( cor );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( radio1 );
            box1.add( radio2 );
            box1.add( radio3 );
            box1.add( radio4 );
            box1.add( Box.createVerticalStrut(12) );
            box1.add( insert_erot_btn );

            JPanel card2 = new JPanel();
            card2.add(box1);

            
            
            
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            
             Box box2 = new Box(BoxLayout.Y_AXIS);
        
        
             JLabel l4=new JLabel("Επέλεξε ποια εξέταση θες να εκκινήσεις");
             l4.setFont(font1);
             l4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
             box2.add( l4 );
             box2.add( Box.createVerticalStrut(12) );
             JCheckBox1 = new ArrayList<JCheckBox>();  
             box2.add( Box.createVerticalStrut(12) );
        
             ArrayList ar_eks_kentrou=new ArrayList();
             URL url1 = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetasi_kentro");
             HttpURLConnection conn1 = (HttpURLConnection) url1.openConnection();
             conn1.setRequestMethod("GET");
             conn1.setRequestProperty("Accept", "application/json");
             if (conn1.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn1.getResponseCode());
            }
             InputStreamReader in1 = new InputStreamReader(conn1.getInputStream());
             BufferedReader br1 = new BufferedReader(in1);
             String output1,result1="";
             while ((output1 = br1.readLine()) != null) 
             {
                result1+=output1;                    
             }
             
            JSONArray arr1 = new JSONArray(result1);     
            
            for (int i = 0; i < arr1.length(); i++) 
                 { // Walk through the Array.
                       JSONObject obj = arr1.getJSONObject(i);
                       String code = obj.getString("code");
                       String date = obj.getString("date");
                       String time = obj.getString("time");
                       String name = obj.getString("name");
                       String address = obj.getString("address");
                       
                       eksetasi_kentro k=new eksetasi_kentro(code,date,time,name,address);
                       ar_eks_kentrou.add(k);
                 }
       
       
      
                for(int i=0;i<ar_eks_kentrou.size();i++)
                {  
                        eksetasi_kentro q4=(eksetasi_kentro)ar_eks_kentrou.get(i);          
                        JCheckBox cb = new JCheckBox(q4.getCode()+'-'+q4.getDate()+'-'+q4.getTime()+'-'+q4.getName()+'-'+q4.getAddress()); 
                        cb.setFont(font2);     //φτιαχνω checkboxes για καθε κεντρο και το προσθετω στο box2 ωστε να μπορω να το εκκινησω
                        JCheckBox1.add(cb);

                        cb.setAlignmentX(JComponent.CENTER_ALIGNMENT);
                        box2.add( Box.createVerticalStrut(12) );
                        box2.add(cb);     
                 };
          
                JButton start_btn=new JButton("Εκκίνηση");
                start_btn.setFont(font1);
                start_btn.addActionListener(this);
                start_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
                box2.add(start_btn);

                JPanel card3 = new JPanel();
                card3.add(box2);
        
            
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


         Box box3 = new Box(BoxLayout.Y_AXIS);
         JLabel addr=new JLabel("Διεύθυνση");
         addr.setFont(font1);
         txt_addr=new JTextField("",15);
         txt_addr.setFont(font4);
         
         JLabel onoma_kentrou=new JLabel("Όνομα κέντρου");
         onoma_kentrou.setFont(font1);
         txt_name_kentrou=new JTextField("",15);
         txt_name_kentrou.setFont(font4);
         
         JButton insert_kentrou_btn=new JButton("kαταχώρηση");
         insert_kentrou_btn.setFont(font1);
         insert_kentrou_btn.addActionListener(this);
         
         addr.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_addr.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         onoma_kentrou.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_name_kentrou.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         insert_kentrou_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         
         
         box3.add( addr );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( txt_addr );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( onoma_kentrou );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( txt_name_kentrou );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( Box.createVerticalStrut(12) );
         box3.add( insert_kentrou_btn );
         
         

        JPanel card4 = new JPanel();
        card4.add(box3);
            
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          JPanel card5 = new JPanel();
          card5.revalidate();
          card5.repaint();         


         Box box4 = new Box(BoxLayout.Y_AXIS);
         JLabel date=new JLabel("Ημερομηνία");
         date.setFont(font1);
         txt_date=new JTextField("",15);
         txt_date.setFont(font4);
         
         JLabel time=new JLabel("Ώρα");
         time.setFont(font1);
         txt_time=new JTextField("",15);
         txt_time.setFont(font4);
         
         JButton insert_btn_eksetasis=new JButton("Εισαγωγη(εξετασης)");
         insert_btn_eksetasis.setFont(font1);
         insert_btn_eksetasis.addActionListener(this);
         ArrayList el_ar_kentrou=new ArrayList();
          
         comb1 = new JComboBox();
                   
         URL oracle1 = new URL("http://localhost:8080/Services_rest/webresources/get_el/kentrou");
          HttpURLConnection conn3 = (HttpURLConnection) oracle1.openConnection();
            conn3.setRequestMethod("GET");
            conn3.setRequestProperty("Accept", "application/json");
            if (conn3.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn3.getResponseCode());
            }
            InputStreamReader in3 = new InputStreamReader(conn3.getInputStream());
            BufferedReader br3 = new BufferedReader(in3);
            String output3,result3="";
            while ((output3 = br3.readLine()) != null) 
            {
                result3+=output3;   
            }
            
            JSONArray arr2 = new JSONArray(result3);
                                     
            for (int i = 0; i < arr2.length(); i++) 
                 { // Walk through the Array.
                       JSONObject obj = arr2.getJSONObject(i);
                        String code = obj.getString("code");
                       String name = obj.getString("name");
                       String address = obj.getString("address");
                       kentro k=new kentro(code,name,address);
                       el_ar_kentrou.add(k);
                 }

           
            for(int p=0;p<el_ar_kentrou.size();p++)   
            {
                kentro k=(kentro)el_ar_kentrou.get(p); 

                comb1.addItem(k.getCode()+'-'+k.getName()+"-"+k.getAddress());
            }
          comb1.setFont(font3);  
          JLabel eks_k=new JLabel("Εξεταστικό κέντρο");
          eks_k.setFont(font1);
         
         eks_k.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         date.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_date.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         time.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_time.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         comb1.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         insert_btn_eksetasis.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         
         
         box4.add( date );
         box4.add( Box.createVerticalStrut(12) );
         
         box4.add( txt_date );
         box4.add( Box.createVerticalStrut(12) );
        
         box4.add( time );
         box4.add( Box.createVerticalStrut(12) );
       
         box4.add( txt_time );
         box4.add( Box.createVerticalStrut(12) );   
         
          box4.add( eks_k );
         box4.add( Box.createVerticalStrut(12) ); 
         box4.add( comb1 );    
          box4.add( Box.createVerticalStrut(12) );
         box4.add( insert_btn_eksetasis );
   
        
        
          card5.add(box4);
         
          
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


         Box box5 = new Box(BoxLayout.Y_AXIS);
         JLabel username_admin=new JLabel("Συνθηματικό");
         username_admin.setFont(font1);
         txt_username_admin=new JTextField("",15);
         txt_username_admin.setFont(font4);
         
         JLabel password_admin=new JLabel("Κωδικός");
         password_admin.setFont(font1);
         txt_password_admin=new JTextField("",15);
         txt_password_admin.setFont(font4);
          comb2 = new JComboBox();
          for(int p=0;p<el_ar_kentrou.size();p++)   
            {
                kentro k=(kentro)el_ar_kentrou.get(p); 

                comb2.addItem(k.getCode()+'-'+k.getName()+"-"+k.getAddress());
            }
         comb2.setFont(font3);
         JButton insert_admin_btn=new JButton("Εισαγωγή διαχειριστή");
         insert_admin_btn.setFont(font1);
         insert_admin_btn.addActionListener(this);
         
    
         
         username_admin.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_username_admin.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         password_admin.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         txt_password_admin.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         comb2.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         insert_admin_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
         
         
         
         box5.add( username_admin );
         box5.add( Box.createVerticalStrut(12) );
         
         box5.add( txt_username_admin );
         box5.add( Box.createVerticalStrut(12) );
         
         box5.add( password_admin );
         box5.add( Box.createVerticalStrut(12) );
         
         box5.add( txt_password_admin );
         box5.add( Box.createVerticalStrut(12) );
         
         box5.add( comb2 );
         box5.add( Box.createVerticalStrut(12) );
         
         box5.add( insert_admin_btn );
         box5.add( Box.createVerticalStrut(12) );
         
         JPanel card6 = new JPanel();
         card6.add(box5);
         
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

 
 
 
          URL oracle2 = new URL("http://localhost:8080/Services_rest/webresources/get_el/res_by_kodiko");
          HttpURLConnection conn4 = (HttpURLConnection) oracle2.openConnection();
            conn4.setRequestMethod("GET");
            conn4.setRequestProperty("Accept", "application/json");
            if (conn4.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn4.getResponseCode());
            }
            InputStreamReader in4 = new InputStreamReader(conn4.getInputStream());
            BufferedReader br4 = new BufferedReader(in4);
            String output4,result4="";
            while ((output4 = br4.readLine()) != null) {
                //       System.out.println(output);
                result4+=output4;
                
            }
            
           JSONArray arr3 = new JSONArray(result4);
               ArrayList results=new ArrayList();                          
            for (int i = 0; i < arr3.length(); i++) 
                 { // Walk through the Array.
                       JSONObject obj = arr3.getJSONObject(i);
                        String code = obj.getString("code");
                       String name = obj.getString("name");
                       String username1 = obj.getString("username");
                       String question = obj.getString("question");
                       String answer = obj.getString("answer");
                       String correct = obj.getString("correct");
                       String true_false = obj.getString("true_false");
                       results_ana_kodiko k=new results_ana_kodiko(code,name,username1,question,answer,correct,true_false);
                       results.add(k);
                 }

  
 
                 
         String header[] = new String[] { "Κωδικός", "Όνομα", "Συνθηματικό","Ερώτηση","Δοθείσα απάντηση","Σωστή απάντηση","Ορθότητα" };
          
         JTable tbl = new JTable();
         DefaultTableModel dtm = new DefaultTableModel(0, 0);
         tbl.setEnabled(false);    
    
         dtm.setColumnIdentifiers(header);

         tbl.setModel(dtm);
         tbl.getColumn(header[0]).setPreferredWidth(65);
         tbl.getColumn(header[3]).setPreferredWidth(800);
         tbl.getColumn(header[4]).setPreferredWidth(130);
         tbl.getColumn(header[5]).setPreferredWidth(124);
         tbl.setRowHeight(30);
         tbl.setFont(font3);
         tbl.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));     
         int size=results.size();    
         for(int i=0;i<size;i++)
            {   String true_false="";
                results_ana_kodiko k=(results_ana_kodiko)results.get(i);
                if(k.getTrue_false().equals("true"))
                    true_false="Σωστή";
                else
                    true_false="Λάθος";
                dtm.addRow(new Object[] { k.getCode(),k.getName(), k.getUsername(), k.getQuestion(), k.getAnswer(), k.getCorrect(),true_false });
           
            }

            JScrollPane scrollPane = new JScrollPane(tbl,   JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);   
            scrollPane.setPreferredSize(new Dimension(1419, 513));
            JPanel card7 = new JPanel();
            card7.add(scrollPane);
         
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
           


           URL oracle5 = new URL("http://localhost:8080/Services_rest/webresources/get_el/res_by_eksetasi");
           HttpURLConnection conn5 = (HttpURLConnection) oracle5.openConnection();
            conn5.setRequestMethod("GET");
            conn5.setRequestProperty("Accept", "application/json");
            if (conn5.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn5.getResponseCode());
            }
            InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
            BufferedReader br5 = new BufferedReader(in5);
            String output5,result5="";
            while ((output5 = br5.readLine()) != null) {
                //       System.out.println(output);
                result5+=output5;
                
            }

                                  JSONArray arr4 = new JSONArray(result5);
                
                                    ArrayList results1=new ArrayList();                    
                                     for (int i = 0; i < arr4.length(); i++) 
                                          { // Walk through the Array.
                                                JSONObject obj = arr4.getJSONObject(i);
                                                String eksetasi_time = obj.getString("eksetasi_time");
                                                
                                                String eksetasi_code = obj.getString("eksetasi_code");
                                                 
                                                String date2 = obj.getString("date");
                                                
                                                String name = obj.getString("name");
                                                
                                                String username2 = obj.getString("username");
                                                
                                                String question = obj.getString("question");
                                                
                                                String answer = obj.getString("answer");
                                                
                                                String correct=obj.getString("correct");
                                                
                                                String true_false=obj.getString("true_false");
                         
                                                results_by_eksetasi k=new results_by_eksetasi(eksetasi_code,date2,eksetasi_time,name,username2,question,answer,correct,true_false);
                                                results1.add(k);

                                             
                 
                                          }
 

              
          String header1[] = new String[] { "Κωδικός","Ημερομηνία","Ώρα","Όνομα", "Συνθηματικό","Ερώτηση","Δοθείσα απάντηση","Σωστή απάντηση","Ορθότητα" };
          
         JTable tbl1 = new JTable();
         DefaultTableModel dtm1 = new DefaultTableModel(0, 0);
         tbl1.setEnabled(false);    
    
         dtm1.setColumnIdentifiers(header1);
         tbl1.setModel(dtm1);  
         tbl1.getColumn(header1[0]).setPreferredWidth(65);
         tbl1.getColumn(header1[1]).setPreferredWidth(90);
         tbl1.getColumn(header1[5]).setPreferredWidth(770);
         tbl1.setRowHeight(30);
         tbl1.setFont(font3);
         tbl1.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
     
         int size1=results1.size();    
         for(int i=0;i<size1;i++)
            {  
                String true_false="";
                results_by_eksetasi k=(results_by_eksetasi)results1.get(i);
                if(k.getTrue_false().equals("true"))
                    true_false="Σωστή";
                else
                    true_false="Λάθος";
                
                
                dtm1.addRow(new Object[] {k.getEksetasi_code(), k.getDate(),k.getEksetasi_time(), k.getName(),k.getUsername(), k.getQuestion(), k.getAnswer(), k.getCorrect(),true_false });
           
            }

            JScrollPane scrollPane1 = new JScrollPane(tbl1,   JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);   
            scrollPane1.setPreferredSize(new Dimension(1419, 513));
            JPanel card8 = new JPanel();
            card8.add(scrollPane1);
         
         
         
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////      

            URL oracle6= new URL("http://localhost:8080/Services_rest/webresources/get_el/res_by_date");
            HttpURLConnection conn6 = (HttpURLConnection) oracle6.openConnection();
            conn6.setRequestMethod("GET");
            conn6.setRequestProperty("Accept", "application/json");
            if (conn6.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn6.getResponseCode());
            }
            InputStreamReader in6 = new InputStreamReader(conn6.getInputStream());
            BufferedReader br6 = new BufferedReader(in6);
            String output6,result6="";
            while ((output6 = br6.readLine()) != null) {
                //       System.out.println(output);
                result6+=output6;
                 
            }   
                                      JSONArray arr6 = new JSONArray(result6);
                
                                     ArrayList results10=new ArrayList();                    
                                     for (int i = 0; i < arr6.length(); i++) 
                                          { // Walk through the Array.
                                                JSONObject obj = arr6.getJSONObject(i);
                                                String ekskentro_name = obj.getString("ekskentro_name");
                                                String date5 = obj.getString("date");
                                                
                                                String name = obj.getString("name");
                                                
                                                String username5 = obj.getString("username");
                                                
                                                String question = obj.getString("question");
                                                
                                                String answer = obj.getString("answer");
                                                
                                                String correct=obj.getString("correct");
                                                
                                                String true_false=obj.getString("true_false");
                                                
                                                results_by_date k=new results_by_date(ekskentro_name,date5,name,username5,question,answer,correct,true_false);

                                                results10.add(k); 
                 
                                          }
                     String header2[] = new String[] { "Εξ-κέντρο","Ημερομηνία","Όνομα", "Συνθηματικό","Ερώτηση","Δοθείσα απάντηση","Σωστή απάντηση","Ορθότητα" };
          
         JTable tbl2 = new JTable();
         DefaultTableModel dtm2 = new DefaultTableModel(0, 0);
         tbl2.setEnabled(false);      
         dtm2.setColumnIdentifiers(header2);
         tbl2.setModel(dtm2);
        // tbl.getColumn(header[3]).setPreferredWidth();
        
         tbl2.getColumn(header2[4]).setPreferredWidth(770);
         tbl2.setRowHeight(30);
         tbl2.setFont(font3);
         tbl2.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        //dtm.addRow(new Object[] {"Κωδικός","Όνομα", "Συνθηματικό","Ερώτηση" ,"Δοθείσα απάντηση" , "Σωστή απάντηση", "Ορθότητα"});
     
         int size2=results10.size();    
         for(int i=0;i<size2;i++)
            {  String true_false;
                results_by_date k=(results_by_date)results10.get(i);
                if(k.getTrue_false().equals("true"))
                    true_false="Σωστή";
                else
                    true_false="Λάθος";
                dtm2.addRow(new Object[] {k.getEkskentro_name(), k.getDate(),  k.getName(),k.getUsername(), k.getQuestion(), k.getAnswer(), k.getCorrect(),true_false });
           
            }
 
            JScrollPane scrollPane2 = new JScrollPane(tbl2,   JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);   
            scrollPane2.setPreferredSize(new Dimension(1419, 513));
            JPanel card9 = new JPanel();
            card9.add(scrollPane2);    


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


             
           ArrayList<el_eksetazomenou> elements=new ArrayList();             
            URL oracle7= new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetazomenou");
            HttpURLConnection conn7 = (HttpURLConnection) oracle7.openConnection();
            conn7.setRequestMethod("GET");
            conn7.setRequestProperty("Accept", "application/json");
            if (conn7.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn7.getResponseCode());
            }
            InputStreamReader in7 = new InputStreamReader(conn7.getInputStream());
            BufferedReader br7 = new BufferedReader(in7);
            String output7,result7="";
            while ((output7 = br7.readLine()) != null) {
                //       System.out.println(output);
                result7+=output7;
                 
            }   
           
           JSONArray arr7 = new JSONArray(result7);
                                    
                                     for (int i = 0; i < arr7.length(); i++) 
                                          { // Walk through the Array.
                                                JSONObject obj = arr7.getJSONObject(i);
                                                String code = obj.getString("code");
                                                String name = obj.getString("name");
                                                String username6 = obj.getString("username");
                                                el_eksetazomenou k=new el_eksetazomenou(code,name,username6);
                                                elements.add(k); 
                 
                                          }
      
           
 
                               
                   
            comb3 = new JComboBox();
                   
            JPanel card10= new JPanel();
            for(int p=0;p<elements.size();p++)   
            {
                el_eksetazomenou k=(el_eksetazomenou)elements.get(p); 

                comb3.addItem(k.getCode()+'-'+k.getName()+"-"+k.getUsername());
                 
                card10.add(comb3);
            }
            comb3.setFont(font3);
            JTable tbl3 = new JTable();
             comb3.addItemListener(new ItemListener() {
     
                public void itemStateChanged(ItemEvent event) {
                 if (event.getStateChange() == ItemEvent.SELECTED) {
                     try {
                         String item = (String) event.getItem();
                         String [] item2 =item.split("-");
                         URL oracle = new URL("http://localhost:8080/Services_rest/webresources/get_el/res_by_choice/"+item2[0] );
                         HttpURLConnection conn5 = (HttpURLConnection) oracle.openConnection();
                         conn5.setRequestMethod("GET");
                         conn5.setRequestProperty("Accept", "application/json");
                         if (conn5.getResponseCode() != 200) {
                             throw new RuntimeException("Failed : HTTP Error code : "
                                     + conn5.getResponseCode());
                         }
                         InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
                         BufferedReader br = new BufferedReader(in5);
                         String output,result2="";
                         while ((output = br.readLine()) != null) {
                             //       System.out.println(output);
                             result2+=output;
                             
                         }
                         
                           JSONArray arr = new JSONArray(result2);
                
                                     ArrayList results3=new ArrayList();                        
                                     for (int i = 0; i < arr.length(); i++) 
                                          { // Walk through the Array.
                                                JSONObject obj = arr.getJSONObject(i);
                                                String question = obj.getString("question");
                                                String name = obj.getString("name");
                                                String username = obj.getString("username");
                                                String answer = obj.getString("answer");
                                                String time = obj.getString("time");
                                                String correct = obj.getString("correct");
                                                String true_false=obj.getString("true_false");
                                                result_by_choice k=new result_by_choice(name,username,question,answer,correct,time,true_false);
                                                results3.add(k); 
                 
                                          }
                         
                          
                         String header3[] = new String[] {  "Όνομα", "Συνθηματικό","Ερώτηση","Δοθείσα απάντηση","Σωστή απάντηση","Ώρα","Ορθότητα" };
                         DefaultTableModel dtm3 = new DefaultTableModel(0, 0);
                         tbl3.setEnabled(false);
                         dtm3.setColumnIdentifiers(header3);
                         tbl3.setModel(dtm3);
                         tbl3.getColumn(header3[2]).setPreferredWidth(770);
                         tbl3.setRowHeight(30);
                         tbl3.setFont(font3);
                         tbl3.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
                         int size3=results3.size();
                         for(int i=0;i<size3;i++)
                         {
                             String true_false;
                             result_by_choice k=(result_by_choice)results3.get(i);
                              if(k.getTrue_false().equals("true")) 
                                    true_false="Σωστή";
                                else
                                    true_false="Λάθος";
                             dtm3.addRow(new Object[] { k.getName(),k.getUsername(), k.getQuestion(), k.getAnswer(), k.getCorrect(),k.getTime(),true_false });
                         }
                     } catch (MalformedURLException ex) {
                         Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                     } catch (IOException ex) {
                         Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                     } catch (JSONException ex) {
                         Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                     }

                       

                 }
                 }
            });
            
 
              

             
             
             JScrollPane scrollPane3 = new JScrollPane(tbl3,   JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);   
             
             scrollPane3.setPreferredSize(new Dimension(1419, 513));
             card10.add(scrollPane3); 


            tabbedPane.addTab("Εισαγωγή εξεταζομένων", card1);
            tabbedPane.addTab("Εισαγωγή ερωτήσεων", card2);
            tabbedPane.addTab("Εκκίνηση εξέτασης", card3);
            tabbedPane.addTab("Εισαγωγή στοιχείων εξεταστικού κέντρου", card4);
            tabbedPane.addTab("Εισαγωγή στοιχείων εξέτασης", card5);
            tabbedPane.addTab("Εισαγωγή admin κέντρου", card6);
            tabbedPane.addTab("Αποτελέσματα ανά εξεταζόμενο", card7);
            tabbedPane.addTab("Αποτελέσματα ανά εξέταση", card8);
            tabbedPane.addTab("Αποτελέσματα ανά ημερομηνία", card9);
            tabbedPane.addTab("Αποτελέσματα ανά επιλογή", card10);
               
            pane.add(tabbedPane, BorderLayout.CENTER);
        } catch (MalformedURLException ex) {
            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("Δικτυακός");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        AdminOp demo = new AdminOp();
        demo.addComponentToPane(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        /* Use an appropriate Look and Feel */
        try {
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);
        
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
    String c=ae.getActionCommand();
      if(c.equals("Καταχώρηση ερωτήσεων"))
          {

                try {
                    String erotisi=txt_erot.getText();
                    String ans1=txt_ans1.getText();
                    String ans2=txt_ans2.getText();
                    String ans3=txt_ans3.getText();
                    String ans4=txt_ans4.getText();
                    String correct="";
                    if(erotisi.equals(" ") || ans1.equals("") || ans2.equals("") || ans3.equals("") || ans4.equals("") )
                        JOptionPane.showMessageDialog(this,"Συμπλήρωσε τα κενά ");
                    else
                    {
                                if(radio1.isSelected())
                                    correct=ans1;
                                else if(radio2.isSelected())
                                    correct=ans2;
                                else if(radio3.isSelected())
                                    correct=ans3;
                                else if(radio4.isSelected())
                                    correct=ans4;

                                String url1="";
                                StringBuilder builder =null;
                                erotisi = erotisi.replace(" ", "%20");
                                char last=  erotisi.charAt(erotisi.length() - 1);  //παιρνω τον τελευταιο χαρακτηρα της ερωτησης αν ειναι ερωτηματικο το αφαιρω γτ δεν το δεχεται το url


                                if(last=='?' || last==';')   
                                {
                                    builder = new StringBuilder(erotisi);
                                    builder.deleteCharAt(erotisi.length() - 1);
                                    url1="http://localhost:8080/Services_rest/webresources/insert/insert_questions/"+builder+"/"+ans1+"/"+ans2+"/"+ans3+"/"+ans4+"/"+correct;    
                                }
                                else
                                {
                                    url1="http://localhost:8080/Services_rest/webresources/insert/insert_questions/"+erotisi+"/"+ans1+"/"+ans2+"/"+ans3+"/"+ans4+"/"+correct;
                                }

                                URL url = new URL(url1);
                                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                conn.setRequestMethod("GET");
                                conn.setRequestProperty("Accept", "TEXT/PLAIN");

                                if (conn.getResponseCode() != 200) {
                                    throw new RuntimeException("Failed : HTTP Error code : "
                                            + conn.getResponseCode());
                                }InputStreamReader in = new InputStreamReader(conn.getInputStream());
                                BufferedReader br = new BufferedReader(in);
                                String output,result2="";
                                while ((output = br.readLine()) != null) {
                                    //       System.out.println(output);
                                    result2+=output;

                                }
                                txt_erot.setText("");
                                txt_ans1.setText("");
                                txt_ans2.setText("");
                                txt_ans3.setText("");
                                txt_ans4.setText("");
                    }
                } catch (MalformedURLException ex) {
                    Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                }

    }else if(c.equals("Καταχώρηση"))
           {    
                String txt_name1=txt_name.getText();
                String txt_username1=txt_username.getText();
                String txt_password1=txt_password.getText();

                    if(txt_name1.equals("") || txt_username1.equals("") || txt_password1.equals(""))
                    {JOptionPane.showMessageDialog(this,"Συμπλήρωσε όλα τα πεδία");}
                    else
                    {
                            try {
                                String selected= (String) comb.getSelectedItem();
                                String value[]= selected.split("-");
                                String obj    =   txt_name1+"-"+txt_username1+"-"+txt_password1+"-"+value[0] ;
                                URL oracle2 = new URL("http://localhost:8080/Services_rest/webresources/insert/insert_eksetazomenou/"+obj);
                                HttpURLConnection conn2 = (HttpURLConnection) oracle2.openConnection();
                                conn2.setRequestMethod("GET");
                                conn2.setRequestProperty("Accept", "text/plain");
                                if (conn2.getResponseCode() != 200) {
                                    throw new RuntimeException("Failed : HTTP Error code : "
                                            + conn2.getResponseCode());
                                }
                                InputStreamReader in1 = new InputStreamReader(conn2.getInputStream());
                                BufferedReader br1 = new BufferedReader(in1);
                                String output1,result1="";
                                while ((output1 = br1.readLine()) != null) {
                                    //       System.out.println(output);
                                    result1+=output1;

                                }                        
                                txt_name.setText("");
                                txt_username.setText("");
                                txt_password.setText("");
                            } catch (MalformedURLException ex) {
                                Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (IOException ex) {
                                Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    }
           }else if(c.equals("Εισαγωγη(εξετασης)"))
              {
            String txt_date1=txt_date.getText();
            String txt_time1=txt_time.getText();
                if(txt_date1.equals("") || txt_time1.equals("") )
                {   JOptionPane.showMessageDialog(this,"Συμπλήρωσε όλα τα πεδία");
                }
                else
                {

                        try {
                            String selected= (String) comb1.getSelectedItem();
                            String value[]= selected.split("-");
                            //txt_time1=txt_time.getText().replace('/', '_');
                            txt_date1=txt_date1.replace('/', '_');
                            txt_time1=txt_time1.replace(" ", "%20");
                            System.out.println(txt_date1);
                            System.out.println(txt_time1);
                            System.out.println(value[1]);
                            URL url = new URL("http://localhost:8080/Services_rest/webresources/insert/insert_eksetasis/"+txt_date1+"/"+txt_time1+"/"+value[1]);
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("GET");
                            conn.setRequestProperty("Accept", "TEXT/PLAIN");
                            if (conn.getResponseCode() != 200) {
                                throw new RuntimeException("Failed : HTTP Error code : "
                                        + conn.getResponseCode());
                            }       InputStreamReader in = new InputStreamReader(conn.getInputStream());
                            BufferedReader br = new BufferedReader(in);
                            String output,result2="";
                            while ((output = br.readLine()) != null) {
                                //       System.out.println(output);
                                result2+=output;

                            }
                            txt_date.setText("");
                            txt_time.setText("");
                        } catch (MalformedURLException ex) {
                            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                        }
       
             }
         
   } else if(c.equals("kαταχώρηση"))
          {
              String name=txt_name_kentrou.getText();
              String addr=txt_addr.getText();
              name=name.replace(" ", "%20");
              addr=addr.replace(" ", "%20");
              if(name.equals("") || addr.equals("") )
              {   JOptionPane.showMessageDialog(this,"Συμπλήρωσε όλα τα πεδία");}
              else
                 {
                  try {
                      String  url="http://localhost:8080/Services_rest/webresources/insert/insert_eks_kentro/"+name+"/"+addr;
                      // String result = Port.insertEksKentrou(name, addr);
                      URL url2 = new URL(url);
                      HttpURLConnection conn = (HttpURLConnection) url2.openConnection();
                      conn.setRequestMethod("GET");
                      conn.setRequestProperty("Accept", "TEXT/PLAIN");
                      if (conn.getResponseCode() != 200) {
                          throw new RuntimeException("Failed : HTTP Error code : "
                                  + conn.getResponseCode());
                      }
                      InputStreamReader in = new InputStreamReader(conn.getInputStream());
                      BufferedReader br = new BufferedReader(in);
                      String output,result2="";
                      while ((output = br.readLine()) != null) {
                          //       System.out.println(output);
                          result2+=output;
                          
                      }
                      txt_name_kentrou.setText("");
                      txt_addr.setText("");
                  } catch (MalformedURLException ex) {
                      Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                  } catch (IOException ex) {
                      Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                  }
                 }

          }else if(c.equals("Εισαγωγή διαχειριστή"))
          {
       
              String username=txt_username_admin.getText();
              String password=txt_password_admin.getText();
              if(username.equals("") || password.equals("") )
              {        JOptionPane.showMessageDialog(this,"Συμπλήρωσε όλα τα πεδία");}  
              else
                 {
                  try {
                      String selected= (String) comb2.getSelectedItem();
                      String value[]= selected.split("-");
                      
                      URL url2 = new URL("http://localhost:8080/Services_rest/webresources/insert/add_admin1/"+username+"/"+password+"/"+value[1]);
                      HttpURLConnection conn5 = (HttpURLConnection) url2.openConnection();
                      conn5.setRequestMethod("GET");
                      conn5.setRequestProperty("Accept", "TEXT/PLAIN");
                      if (conn5.getResponseCode() != 200) {
                          throw new RuntimeException("Failed : HTTP Error code : "
                                  + conn5.getResponseCode());
                      }
                      InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
                      BufferedReader br = new BufferedReader(in5);
                      String output,result2="";
                      while ((output = br.readLine()) != null) {
                          //       System.out.println(output);
                          result2+=output;
                          
                      }
                      
                      txt_password_admin.setText("");
                      txt_username_admin.setText("");
                  } catch (MalformedURLException ex) {
                      Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                  } catch (IOException ex) {
                      Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
                  }
                 }
               
              
      
	       
          }else if(c.equals("Εκκίνηση"))
          {
       
         try {
            String total_codes="";
            if(JCheckBox1.size()==0)
            { JOptionPane.showMessageDialog(this,"Δεν υπάρχει εξέταση προς εκκίνηση");return;}
            
            for (int i = JCheckBox1.size() - 1; i >=0; i--)
            {
                JCheckBox cb = JCheckBox1.get(i);
                if (cb.isSelected())
                {
                    String  total =cb.getText();
                    String[] table= total.split("-");
                    total_codes+="-"+table[0];
                }
            }
            URL url2 = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetasi_kentro/"+total_codes);
            HttpURLConnection conn5 = (HttpURLConnection) url2.openConnection();
            conn5.setRequestMethod("GET");
            conn5.setRequestProperty("Accept", "TEXT/PLAIN");
            if (conn5.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn5.getResponseCode());
            }
            InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
            BufferedReader br = new BufferedReader(in5);
            String output,result2="";
            while ((output = br.readLine()) != null) {
                //       System.out.println(output);
                result2+=output;
                
            }
           
        } catch (MalformedURLException ex) {
            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AdminOp.class.getName()).log(Level.SEVERE, null, ex);
        }
      
	       
          } else if(c.equals("Έξοδος"))
              System.exit(0);   
}
}
