/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest1;

 
import client_diktiakos1_rest.classes.eksetasi;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
 

/**
 *
 * @author giannis21
 */
public class AdminKentrou extends JFrame implements ActionListener{
       ArrayList<JCheckBox> JCheckBox1;
    AdminKentrou(String code){
        
           try {
               FlowLayout fl=new FlowLayout(FlowLayout.CENTER);
               this.setLayout(fl);
               URL oracle = new URL("http://localhost:8080/Services_rest/webresources/get_el/specific_exam/"+code);
               HttpURLConnection conn5 = (HttpURLConnection) oracle.openConnection();
               conn5.setRequestMethod("GET");
               conn5.setRequestProperty("Accept", "application/json");
               if (conn5.getResponseCode() != 200) {
                   throw new RuntimeException("Failed : HTTP Error code : "
                           + conn5.getResponseCode());
               }
               InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
               BufferedReader br = new BufferedReader(in5);
               String output,result2="";
               while ((output = br.readLine()) != null) {
                   //       System.out.println(output);
                   result2+=output;
                   
               }
               JSONArray arr = new JSONArray(result2);
               ArrayList ar_eks_kentrou=new ArrayList();
               ArrayList results=new ArrayList();
               for (int i = 0; i < arr.length(); i++)
               { // Walk through the Array.
                   JSONObject obj = arr.getJSONObject(i);
                   
                   String code1 = obj.getString("code");
                   String date = obj.getString("date");
                   String time=obj.getString("time");
                   eksetasi k=new eksetasi(code1,date,time);
                   
                   ar_eks_kentrou.add(k);
                   
               }
               Box box2 = new Box(BoxLayout.Y_AXIS);
               Font font2 = new Font("SansSerif", Font.BOLD, 30);
               JLabel l4=new JLabel("Επέλεξε ποια εξέταση θες να εκκινήσεις από αυτό το κέντρο");
               l4.setFont(font2);
               l4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
               box2.add( l4 );
               box2.add( Box.createVerticalStrut(12) );
               JCheckBox1 = new ArrayList<JCheckBox>();
               box2.add( Box.createVerticalStrut(12) );
               
                
               for(int i=0;i<ar_eks_kentrou.size();i++)
               {
                   eksetasi q4=(eksetasi)ar_eks_kentrou.get(i);
                   
                   JCheckBox cb = new JCheckBox(q4.getCode()+'-'+q4.getDate()+'-'+q4.getTime());
                   cb.setFont(font2);
                   JCheckBox1.add(cb);
                   
                   cb.setAlignmentX(JComponent.CENTER_ALIGNMENT);
                   box2.add(cb);
               }    
               JButton start_btn=new JButton("Εκκίνηση");
               start_btn.setFont(font2);
               start_btn.addActionListener(this);
               start_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
               box2.add(start_btn);
               add(box2);
           } catch (MalformedURLException ex) {
               Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
           } catch (IOException ex) {
               Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
           } catch (JSONException ex) {
               Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
           }
       
} 
    @Override
    public void actionPerformed(ActionEvent ae) {
           String c=ae.getActionCommand();
        if(c.equals("Εκκίνηση"))
          {
       
               try {
                   String total_codes="";
                   for (int i = JCheckBox1.size() - 1; i >=0; i--)
                   {
                       JCheckBox cb = JCheckBox1.get(i);
                       if (cb.isSelected())
                       {
                           String  total =cb.getText();
                           String[] table= total.split("-");
                           total_codes+="-"+table[0];
                       }
                   }
                   URL oracle2 = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetasi_kentro/"+total_codes);
                   HttpURLConnection conn6 = (HttpURLConnection) oracle2.openConnection();
                   conn6.setRequestMethod("GET");
                   conn6.setRequestProperty("Accept", "text/plain");
                   if (conn6.getResponseCode() != 200) {
                       throw new RuntimeException("Failed : HTTP Error code : "
                               + conn6.getResponseCode());
                   }   InputStreamReader in5 = new InputStreamReader(conn6.getInputStream());
                   BufferedReader br = new BufferedReader(in5);
                   String output,result2="";
                   while ((output = br.readLine()) != null) {
                       //       System.out.println(output);
                       result2+=output;
                       
                   }
               } catch (MalformedURLException ex) {
                   Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
               } catch (IOException ex) {
                   Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
               }
                 
       
	       
          }
    }
    public static void main(String[] args) {
    
    //  session.setAttribute("username", "");
      
        AdminKentrou b=new AdminKentrou("1");
        b.setTitle("Δικτυακός");
        b.setSize(new Dimension(946,677));
       
        b.setVisible(true); 
    }
}
