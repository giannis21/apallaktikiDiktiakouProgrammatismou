﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_diktiakos1_rest1;

import client_diktiakos1_rest.classes.eksetasi;
import client_diktiakos1_rest.classes.el_eksetazomenou;
import client_diktiakos1_rest.classes.kentro;
import client_diktiakos1_rest.classes.result_by_choice;
//import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AdminKentrou1  extends JFrame implements ActionListener {
    final static String BUTTONPANEL = "Tab with JButtons";
    final static String TEXTPANEL = "Tab with JTextField";
    final static int extraWindowWidth = 200;
    ArrayList<JCheckBox> JCheckBox1;
    ArrayList<JSONObject>  JComboBox1; 
   
    JFrame f;  
AdminKentrou1(String code){  
       try {
           f=new JFrame();
           URL oracle = new URL("http://localhost:8080/Services_rest/webresources/get_el/specific_exam/"+code);
           HttpURLConnection conn5 = (HttpURLConnection) oracle.openConnection();
           conn5.setRequestMethod("GET");
           conn5.setRequestProperty("Accept", "application/json");
           if (conn5.getResponseCode() != 200) {
               throw new RuntimeException("Failed : HTTP Error code : "
                       + conn5.getResponseCode());
           }
           InputStreamReader in5 = new InputStreamReader(conn5.getInputStream());
           BufferedReader br = new BufferedReader(in5);
           String output,result2="";
           while ((output = br.readLine()) != null) {
               //       System.out.println(output);
               result2+=output;
               
           }
           JSONArray arr = new JSONArray(result2);
           ArrayList ar_eks_kentrou=new ArrayList();
           ArrayList results=new ArrayList();
           for (int i = 0; i < arr.length(); i++)
           { // Walk through the Array.
               JSONObject obj = arr.getJSONObject(i);
               
               String code1 = obj.getString("code");
               String date = obj.getString("date");
               String time=obj.getString("time");
               eksetasi k=new eksetasi(code1,date,time);
               
               ar_eks_kentrou.add(k);
               
           }
           Box box2 = new Box(BoxLayout.Y_AXIS);
           Font font2 = new Font("SansSerif", Font.BOLD, 30);
           JLabel l4=new JLabel("Επέλεξε ποια εξέταση θες να εκκινήσεις από αυτό το κέντρο");
           l4.setFont(font2);
           l4.setAlignmentX(JComponent.CENTER_ALIGNMENT);
           box2.add( l4 );
           box2.add( Box.createVerticalStrut(12) );
           JCheckBox1 = new ArrayList<JCheckBox>();
           box2.add( Box.createVerticalStrut(12) );
           for(int i=0;i<ar_eks_kentrou.size();i++)
           {
               eksetasi q4=(eksetasi)ar_eks_kentrou.get(i);
               
               JCheckBox cb = new JCheckBox(q4.getCode()+'-'+q4.getDate()+'-'+q4.getTime());
               cb.setFont(font2);  
               JCheckBox1.add(cb);
               
               cb.setAlignmentX(JComponent.CENTER_ALIGNMENT);
               box2.add(cb);
           }
          
           JButton start_btn=new JButton("Εκκίνηση");
           start_btn.setFont(font2);
           start_btn.addActionListener(this);
           start_btn.setAlignmentX(JComponent.CENTER_ALIGNMENT);
           box2.add(start_btn);
           
           JPanel p1=new JPanel();
           p1.add(box2);
           
           JTabbedPane tp=new JTabbedPane();
           tp.setBounds(0,0,1000,1000);
           tp.add("Εκκίνηση εξέτασης",p1);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
           






           URL oracle1 = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetazomenou");
           HttpURLConnection conn6 = (HttpURLConnection) oracle1.openConnection();
           conn6.setRequestMethod("GET");
           conn6.setRequestProperty("Accept", "application/json");
           if (conn6.getResponseCode() != 200) {
               throw new RuntimeException("Failed : HTTP Error code : "
                       + conn6.getResponseCode());
           }
           InputStreamReader in6 = new InputStreamReader(conn6.getInputStream());
           BufferedReader br6 = new BufferedReader(in6);
           String output6="",result6="";
           while ((output6 = br6.readLine()) != null) {
               //       System.out.println(output);
               result6+=output6;
               
           }
                 ArrayList<el_eksetazomenou> eksetazomenos=new ArrayList();             
                     
                 JSONArray arr1 = new JSONArray(result6);
                             
                for (int i = 0; i < arr1.length(); i++) 
                     { // Walk through the Array.
                           JSONObject obj = arr1.getJSONObject(i);
                           String code1 = obj.getString("code");
                           String name = obj.getString("name");
                           String username = obj.getString("username");
                           el_eksetazomenou k=new el_eksetazomenou(code1,name,username);
                           eksetazomenos.add(k); 

                     }
 //--------------------------------------------------------------------------------------------------------------------------------------------------               
          
            ArrayList ar = new ArrayList();
           URL oracle6 = new URL("http://localhost:8080/Services_rest/webresources/get_el/specific_exam1/"+code);
           HttpURLConnection conn4 = (HttpURLConnection) oracle6.openConnection();
           conn4.setRequestMethod("GET");
           conn4.setRequestProperty("Accept", "application/json");
           if (conn4.getResponseCode() != 200) {
               throw new RuntimeException("Failed : HTTP Error code : "
                       + conn4.getResponseCode());
           }
           InputStreamReader in4 = new InputStreamReader(conn4.getInputStream());
           BufferedReader br4 = new BufferedReader(in4);
           String output4="",result4="";
           while ((output4 = br4.readLine()) != null) {
               //       System.out.println(output);
               result4+=output4;
               
           }
           
            JSONArray arr2 = new JSONArray(result4);
                                     for (int i = 0; i < arr2.length(); i++) 
                                          { // Walk through the Array.
                                                JSONObject obj = arr2.getJSONObject(i);
                                                String code1 = obj.getString("code");
                                                String date = obj.getString("date");
                                                String time = obj.getString("time");
                                                
                                               
                                                eksetasi k=new eksetasi(code1,date,time);
                                                ar.add(k);
                                          }
                          

        
            
             JPanel p2=new JPanel();
             
             Box box = new Box(BoxLayout.Y_AXIS);
          
           
               

             
            
               
             JComboBox1 = new ArrayList<JSONObject>();   
             Font font3 = new Font("SansSerif", Font.PLAIN, 30);
             Font font4 = new Font("SansSerif", Font.PLAIN, 16);
             for(int j=0;j<eksetazomenos.size();j++)                      
                {   
                   el_eksetazomenou ekset=(el_eksetazomenou)eksetazomenos.get(j);  
                   String code_ekset=ekset.getCode();
                   JLabel eksetazomeno =new JLabel(ekset.getName()+"--"+ekset.getUsername());
                   eksetazomeno.setAlignmentX(JComponent.CENTER_ALIGNMENT); 
                   eksetazomeno.setFont(font3);  
                   box.add( eksetazomeno );
                  
                   JComboBox comb1 = new JComboBox();
                   JSONObject obj = new JSONObject();
                              for(int i=0;i<ar.size();i++) 
                                {
                                           eksetasi k=(eksetasi)ar.get(i);
                                           
                                           String total4=code+"-"+k.getCode();
                                                
                                           comb1.addItem(k.getCode()+"-"+k.getDate()+'-'+k.getTime());
                                           comb1.setAlignmentX(JComponent.CENTER_ALIGNMENT);
                                           comb1.setFont(font4);
                                           box.add( comb1 );
                                           obj.put("eksetazomenos_code", code_ekset);
                                           obj.put("comb", comb1);
    
                                            

                                } 
                              box.add( Box.createVerticalStrut(30) );
                              JComboBox1.add(obj);
                              
                     
                }
  

           //box.add( Box.createVerticalStrut(12) );
           JButton btn=new JButton("Συνέχεια");
           btn.setFont(font3);
           btn.addActionListener(this);
           box.add( btn );
           
           p2.add(box);
          
           
           tp.add("Αντιστοίχιση",p2);
          
           f.add(tp);
           f.setSize(1009,577);
           f.setLayout(null);
           f.setVisible(true);
       } catch (MalformedURLException ex) {
           Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
       } catch (IOException ex) {
           Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
       } catch (JSONException ex) {
           Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
       }
}  
 
    public static void main(String[] args) {
       new AdminKentrou1("1");
   
        
    }

       @Override
    public void actionPerformed(ActionEvent ae) {
           String c=ae.getActionCommand();
        if(c.equals("Εκκίνηση"))
          {
       
               try {
                   String total_codes="";
                     if(JCheckBox1.size()==0)
                      { JOptionPane.showMessageDialog(this,"Δεν υπάρχει εξέταση προς εκκίνηση");return;}
                   for (int i = JCheckBox1.size() - 1; i >=0; i--)
                   {
                       JCheckBox cb = JCheckBox1.get(i);
                       if (cb.isSelected())
                       {
                           String  total =cb.getText();
                           String[] table= total.split("-");
                           total_codes+="-"+table[0];
                       }
                   }
                   URL oracle2 = new URL("http://localhost:8080/Services_rest/webresources/get_el/eksetasi_kentro/"+total_codes);
                   HttpURLConnection conn6 = (HttpURLConnection) oracle2.openConnection();
                   conn6.setRequestMethod("GET");
                   conn6.setRequestProperty("Accept", "text/plain");
                   if (conn6.getResponseCode() != 200) {
                       throw new RuntimeException("Failed : HTTP Error code : "
                               + conn6.getResponseCode());
                   }   InputStreamReader in5 = new InputStreamReader(conn6.getInputStream());
                   BufferedReader br = new BufferedReader(in5);
                   String output,result2="";
                   while ((output = br.readLine()) != null) {
                       //       System.out.println(output);
                       result2+=output;
                       
                   }
               } catch (MalformedURLException ex) {
                   Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
               } catch (IOException ex) {
                   Logger.getLogger(AdminKentrou.class.getName()).log(Level.SEVERE, null, ex);
               }
                 
       
	       
          }else if(c.equals("Συνέχεια"))
          {
               try {
                   String total_codes1="",total_codes2="";
                    
                   for (int i =0;i< JComboBox1.size(); i++)
                   {
                       try {
                           JSONObject cb = JComboBox1.get(i);
                           String eksetazomenos_code = cb.getString("eksetazomenos_code");
                           JComboBox combo=(JComboBox) cb.get("comb");
                           String selected= (String) combo.getSelectedItem();
                           
                           String codes1[]=selected.split("-");
                           total_codes1=eksetazomenos_code+"-"+codes1[0];
                           total_codes2+="_"+total_codes1;
                           
                           
                           
                           
                           
                           //
                           
                           
                           
                           System.out.println(eksetazomenos_code);
                           System.out.println(selected);
                       } catch (JSONException ex) {
                           Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
                       }
                   }
                   URL url1 = new URL("http://localhost:8080/Services_rest/webresources/get_el/correspondance/"+total_codes2);
                   HttpURLConnection conn1 = (HttpURLConnection) url1.openConnection();
                   conn1.setRequestMethod("GET");
                   conn1.setRequestProperty("Accept", "text/plain");
                   if (conn1.getResponseCode() != 200) {
                       throw new RuntimeException("Failed : HTTP Error code : "
                               + conn1.getResponseCode());
                   }
                   InputStreamReader in5 = new InputStreamReader(conn1.getInputStream());
                   BufferedReader br = new BufferedReader(in5);
                   String output,result2="";
                   while ((output = br.readLine()) != null) {
                       //       System.out.println(output);
                       result2+=output;
                       
                   }
               } catch (MalformedURLException ex) {
                   Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
               } catch (IOException ex) {
                   Logger.getLogger(AdminKentrou1.class.getName()).log(Level.SEVERE, null, ex);
               }
          }
    }

   
}
