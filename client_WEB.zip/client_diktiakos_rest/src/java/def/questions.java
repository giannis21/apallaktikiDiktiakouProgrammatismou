package def;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author giannis21
 */
public class questions {
    String erot,ans1,ans2,ans3,ans4,corr;

    public questions(String erot, String ans1, String ans2, String ans3, String ans4, String corr) {
        this.erot = erot;
        this.ans1 = ans1;
        this.ans2 = ans2;
        this.ans3 = ans3;
        this.ans4 = ans4;
        this.corr = corr;
    }

    @Override
    public String toString() {
        return "questions{" + "erot=" + erot + ", ans1=" + ans1 + ", ans2=" + ans2 + ", ans3=" + ans3 + ", ans4=" + ans4 + ", corr=" + corr + '}';
    }

    public String getErot() {
        return erot;
    }

    public String getAns1() {
        return ans1;
    }

    public String getAns2() {
        return ans2;
    }

    public String getAns3() {
        return ans3;
    }

    public String getAns4() {
        return ans4;
    }

    public String getCorr() {
        return corr;
    }
}
