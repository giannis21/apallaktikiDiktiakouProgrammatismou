/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package def;

/**
 *
 * @author giannis21
 */
public class exet_erotiseis {
    String  username,password,quest,apanthsh,Date,Time;

    public exet_erotiseis(String username, String password, String quest, String apanthsh, String Date, String Time) {
        this.username = username;
        this.password = password;
        this.quest = quest;
        this.apanthsh = apanthsh;
        this.Date = Date;
        this.Time = Time;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getQuest() {
        return quest;
    }

    public String getApanthsh() {
        return apanthsh;
    }

    public String getDate() {
        return Date;
    }

    public String getTime() {
        return Time;
    }

}
