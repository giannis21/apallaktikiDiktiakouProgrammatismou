/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.orga;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import static javax.ws.rs.HttpMethod.POST;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author giannis21
 */
@Path("insert")
public class InsertResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of InsertResource
     */
    public InsertResource() {
    }

    /**
     * Retrieves representation of an instance of me.orga.InsertResource
     * @return an instance of java.lang.String
     */
    
    @GET
    @Path("apanthseis_xrhsth/{username}/{password}/{erotisi}/{apanthsh}/{Date}/{Time}")
    @Produces(MediaType.TEXT_PLAIN)
    
    public String getXdml1(@PathParam ("username") String username , @PathParam ("password") String password,@PathParam ("erotisi") String erotisi , @PathParam ("apanthsh") String apanthsh,@PathParam ("Date") String Date , @PathParam ("Time") String Time) throws ClassNotFoundException, SQLException, JSONException  {
           //         JSONObject obj = new JSONObject();
           
         Date= Date.replace("_", "/");
         erotisi+="?";           
                    

            String exetcode = "";
            String erotcode = "";
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
            String sqlstring= "select code from eksetazomenos where username='"+username+"' and password='"+password+"' ";
            ResultSet res=myStatement.executeQuery(sqlstring);
              
               while(res.next()){
                exetcode=res.getString("code");
                  
               }
             String sqlstring2= "select code from questions where question='"+erotisi+"' ";
             ResultSet res1=myStatement.executeQuery(sqlstring2);
            
            
            while(res1.next()){
                 erotcode = res1.getString("code");
             
            }
             String sqlString3 = "INSERT INTO exet_erotiseis(exetcode,erotcode,apanthsh,Date,Time) VALUES('"+exetcode+"', '"+erotcode+"', '"+apanthsh+"','"+Date+"','"+Time+"')";
 
              myStatement.executeUpdate(sqlString3);
                

       
     return username+"----"+erotisi;
    }

    /**
     * PUT method for updating or creating an instance of InsertResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }










@GET
    @Path("insert_eksetazomenou/{name_usern_password_eksetasicode}")
   @Produces(MediaType.TEXT_PLAIN)
    
    public String getXml13(@PathParam ("name_usern_password_eksetasicode") String obj ) throws ClassNotFoundException, SQLException, JSONException  {
           //         JSONObject obj = new JSONObject();
            String array[]=obj.split("-");
           
            String  name= array[0];
            String  username= array[1];
            String  password= array[2];
            String  eksetasi_code= array[3];
            
           
                    
                    

            String exetcode = "";
            String erotcode = "";
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
            Statement myStatement1 = myConnection.createStatement();
            String sqlString = "INSERT INTO eksetazomenos(name,username,password,eksetasi_code,if_approved) VALUES('"+name+"', '"+username+"','"+password+"','"+eksetasi_code+"','0')";
            //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement1.executeUpdate(sqlString);
            
            myStatement1.close();
            myConnection.close();
          

       
     return "1";
    }
    
    
    
    
    @GET
    @Path("insert_questions/{erotisi}/{ans1}/{ans2}/{ans3}/{ans4}/{cor}")
   @Produces(MediaType.TEXT_PLAIN)
    
    public String getXmld113(@PathParam ("erotisi") String erotisi, @PathParam ("ans1") String ans1,@PathParam ("ans2") String ans2 ,@PathParam ("ans3") String ans3, @PathParam ("ans4") String ans4,@PathParam ("cor") String cor) throws ClassNotFoundException, SQLException, JSONException  {
           //         JSONObject obj = new JSONObject();
            
           
                 
                 erotisi=erotisi+"?";
            String exetcode = "";
            String erotcode = "";
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
          
 
            String sqlString = "INSERT INTO questions(question,ans1,ans2,ans3,ans4,corr) VALUES('"+erotisi+"', '"+ans1+"','"+ans2+"','"+ans3+"','"+ans4+"','"+cor+"')";
            //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement.executeUpdate(sqlString);
            
            myStatement.close();
            myConnection.close();
          

       
     return "1";
    }

    
    
        @GET
    @Path("insert_eks_kentro/{name}/{address}")
   @Produces(MediaType.TEXT_PLAIN)
    
    public String getX113( @PathParam ("name") String name,@PathParam ("address") String address) throws ClassNotFoundException, SQLException, JSONException  {

          
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
          
 
            String sqlString = "INSERT INTO eks_kentro(name,address) VALUES('"+name+"', '"+address+"')";
          //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement.executeUpdate(sqlString);
            
            myStatement.close();
            myConnection.close();
          

       
     return name;
    }
    
    
    
    @GET
    @Path("insert_eksetasis/{date}/{time}/{kentro_code}")
    @Produces(MediaType.TEXT_PLAIN)
    
    public String getX113( @PathParam ("date") String date,@PathParam ("time") String time,@PathParam ("kentro_code") int kentro) throws ClassNotFoundException, SQLException, JSONException  {

            date=date.replace("_", "/");
            date=date.replace("-", "/");
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
          
 
            String sqlString = "INSERT INTO eksetasi(date,time,kentro_code,flag) VALUES('"+date+"', '"+time+"', '"+kentro+"','0')";
            //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement.executeUpdate(sqlString);
            
            myStatement.close();
            myConnection.close();
          

       
     return "1";
    }
    
    
    @POST
	@Path("/add_admin")
	public Response apanthseis(
		@FormParam("username") String username,
                @FormParam("password") String password,
                @FormParam("kentro1") String kentro1
                ) throws ClassNotFoundException, SQLException, URISyntaxException {
            Class.forName("com.mysql.jdbc.Driver");
            
            String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            String sqlString = "INSERT INTO admin_kentrou(username,password,kentro_code) VALUES('"+username+"','"+password+"','"+kentro1+"')";
            //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement.executeUpdate(sqlString);
            
            myStatement.close();
            myConnection.close();
               
            
          java.net.URI location = new java.net.URI("http://localhost:8080/client_diktiakos_rest/add_admin_kentrou.jsp");
          return Response.temporaryRedirect(location).build();
            
                 

	}
        
        
        
        
        @GET
    @Path("add_admin1/{username}/{password}/{kodikos_kentro1}")
    @Produces(MediaType.TEXT_PLAIN)
    
    public String getX1213( @PathParam ("username") String username,@PathParam ("password") String password,@PathParam ("kodikos_kentro1") int kentro1) throws ClassNotFoundException, SQLException, JSONException  {

            
       
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
          
 
           Statement myStatement1 = myConnection.createStatement();
            String sqlString = "INSERT INTO admin_kentrou(username,password,kentro_code) VALUES('"+username+"','"+password+"','"+kentro1+"')";
            //  String sqlString = "INSERT INTO eksetazomenos(name,username,password) VALUES('"+i+"', '"+j+"','"+k+"')";
            
            myStatement1.executeUpdate(sqlString);
            
            myStatement1.close();
            myConnection.close();
          

       
     return "1";
    }
        
}
 



