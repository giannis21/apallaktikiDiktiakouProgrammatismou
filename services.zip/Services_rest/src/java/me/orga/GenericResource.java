/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.orga;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import org.json.JSONException;

/**
 * REST Web Service
 *
 * @author giannis21
 */
@Path("generic")
public class GenericResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GenericResource
     */
    public GenericResource() {
    }

    /**
     * Retrieves representation of an instance of me.orga.GenericResource
     * @return an instance of java.lang.String
     */
    
       @GET
       @Path("login_admin/{username_admin}/{password_admin}")
       @Produces(MediaType.TEXT_PLAIN)
       public String Login_admin(@PathParam ("username_admin") String username_admin, @PathParam ("password_admin") String password_admin) throws JSONException, ClassNotFoundException, SQLException {
       Class.forName("com.mysql.jdbc.Driver");
            String username1="";
            String password1=""; 
            
            String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            Connection myConnection = DriverManager.getConnection(myDatabase);
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
           
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
       
            String sqlstring= "select * from admin where username='"+username_admin+"' and password='"+password_admin+"' ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            
            while(res.next()){
                username1=res.getString("username");
                password1=res.getString("password");
               
            }
              myStatement.close();
        myConnection.close();
        
       if(username1.equals("") && password1.equals(""))
              return "0";
           
        //jsonB = jsonB.add("resposible", jsonA);
     
        return "1";
    }
    
     @GET
    @Path("login_eks/{username}/{password}")
    @Produces(MediaType.TEXT_PLAIN)
    public String login_eks(@PathParam ("username") String username, @PathParam ("password") String password) throws ClassNotFoundException, SQLException {
            String username1="";
        String password1="";
        int eksetasi_code=0; int flag = 0;
        
            Class.forName("com.mysql.jdbc.Driver");
           
              String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
            String sqlstring= "select * from eksetazomenos where username='"+username+"' and password='"+password+"' ";
            ResultSet res=myStatement.executeQuery(sqlstring);
           
            while(res.next()){
                username1=res.getString("username");
                password1=res.getString("password");
                eksetasi_code=res.getInt("eksetasi_code");
            }
                 String sql1string1= "select flag,code from eksetasi where flag='1' and code='"+eksetasi_code+"'";
                 ResultSet res1=myStatement.executeQuery(sql1string1);
                 
                        while(res1.next()){
                            flag=res1.getInt("flag");

                            break;
                        } 
             
            if(flag==0)
            {
              if(username1.equals("") && password1.equals("") )
                 return "0";   //oxi ekkinisi kai la8os stoixeia
              else
                  return "1"; //sosta stoixeia alla oxi ekkinisi
              
            }
           else
              return  username1+"#"+password1; }
          
  


  @GET
    @Path("login_admin_kentrou/{username_ad}/{password_ad}")
    @Produces(MediaType.TEXT_PLAIN)
    public String getXml1(@PathParam ("username_ad") String username_ad, @PathParam ("password_ad") String password_ad) throws ClassNotFoundException, SQLException  {


             String flag="0",username1="",password1="",code="";

            Class.forName("com.mysql.jdbc.Driver");
           
            String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
            String sqlstring= "select * from admin_kentrou where username='"+username_ad+"' and password='"+password_ad+"' ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            
            while(res.next()){
                username1=res.getString("username");
                password1=res.getString("password");
                code=res.getString("kentro_code");
               
            }
     
     if(username1.equals("")&& password1.equals(""))
         return "0";      
     
     return code;
    }
    
    
}