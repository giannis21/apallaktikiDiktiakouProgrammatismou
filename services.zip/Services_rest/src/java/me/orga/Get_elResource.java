/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.orga;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author giannis21
 */
@Path("get_el")
public class Get_elResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of Get_elResource
     */
    public Get_elResource() {
    }

    /**
     * Retrieves representation of an instance of me.orga.Get_elResource
     * @return an instance of java.lang.String
     */
  @GET
    @Path("eksetasis")
    @Produces(MediaType.APPLICATION_JSON)
    public String getXml1() throws ClassNotFoundException, SQLException  {


            String record="";
            String all_rec="";
            
            
            Class.forName("com.mysql.jdbc.Driver");
            
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
            
                 JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
         
            String sqlstring= "select * from eksetasi; ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            while(res.next()){             
                
                
             jsonA = jsonA.add(factory.createObjectBuilder()
            .add("code", res.getString("code"))
            .add("date", res.getString("date"))
            .add("time", res.getString("time"))
            
            );
      
            }
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
  
    }
    /**
     * PUT method for updating or creating an instance of Get_elResource
     * @param content representation for the resource
     */
    @GET
    @Path("erotiseis")
    @Produces(MediaType.APPLICATION_JSON)
    public String getXml2() throws ClassNotFoundException, SQLException  {
 String erot="",erot2="";
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
         
            String sqlstring= "select * from questions; ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            while(res.next()){             
                
                   jsonA = jsonA.add(factory.createObjectBuilder()
                   .add("question", res.getString("question"))
                   .add("ans1", res.getString("ans1"))
                   .add("ans2", res.getString("ans2"))
                   .add("ans3", res.getString("ans3"))
                   .add("ans4", res.getString("ans4"))
                   .add("corr", res.getString("corr"))  );
                    
            }
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
  
    }
    
    
    @GET
    @Path("eksetasi_kentro")
    @Produces(MediaType.APPLICATION_JSON)
    public String get_ekset_kentro() throws ClassNotFoundException, SQLException  {
        
        
            String record="";
            String all_rec="",name="",address="";
            String erot="",erot2="";
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
         
            String sqlstring= "select eksetasi.code,date,time,eks_kentro.name,eks_kentro.address from eksetasi,eks_kentro where kentro_code=eks_kentro.code and eksetasi.flag='0'  ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            while(res.next()){             
                
                   jsonA = jsonA.add(factory.createObjectBuilder()
                   .add("code", res.getString("eksetasi.code"))
                   .add("date", res.getString("date"))
                   .add("time", res.getString("time"))
                   .add("name", res.getString("eks_kentro.name"))
                   .add("address", res.getString("eks_kentro.address"))
                      );
                    
            }
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
   
    @GET
    @Path("eksetasi_kentro/{par}")
    @Produces(MediaType.TEXT_PLAIN)
    public String get_ekset_kentro(@PathParam ("par") String eksetasi_code ) throws ClassNotFoundException, SQLException  {
        
        
       Class.forName("com.mysql.jdbc.Driver");
            
            String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            String[] rec=eksetasi_code.split("-");
            String sqlString1="";
            for(int i=0;i<rec.length;i++)
            {
                sqlString1 = "Update eksetasi set flag='1' where code='"+rec[i]+"'"; 
                myStatement.executeUpdate(sqlString1);
            }
         
            
         
            
            myStatement.close();
            myConnection.close();
         return "1";   
    }
    
    @GET
    @Path("correspondance/{codes}")
    @Produces(MediaType.TEXT_PLAIN)
    public String update_eksetazomenou_ekset(@PathParam ("codes") String codes ) throws ClassNotFoundException, SQLException, JSONException  {
        
        
       Class.forName("com.mysql.jdbc.Driver");
            
            String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            
            String []total=codes.split("_");
              
                               //  String [] divide_q=null;
                                
                              String sqlString1="";    
                              String divide_codes1=""; 
                              String divide_codes2=""; 
                              for(int i=1;i<total.length;i++)
                                { 
                                  //  out.println(rec[i]);
                                
                                   String []  divide_codes =total[i].split("-");
                                   divide_codes1=divide_codes[0];
                                    divide_codes2=divide_codes[1];
                                    sqlString1 = "Update eksetazomenos set eksetasi_code='"+divide_codes2+"' where code='"+divide_codes1+"'"; 
                                    myStatement.executeUpdate(sqlString1);
                                   
                                };
                     
   
            
            myStatement.close();
            myConnection.close();
         return divide_codes1+"---"+divide_codes2;   
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
    
    
    
    @GET
    @Path("kentrou")
    @Produces(MediaType.APPLICATION_JSON)
    public String get_el_kentro() throws ClassNotFoundException, SQLException  {
        
        
            String record="";
            String all_rec="",name="",address="";
            String erot="",erot2="";
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
         
             String sqlstring= "select * from eks_kentro; ";
            ResultSet res=myStatement.executeQuery(sqlstring);
            while(res.next()){             
                
                   jsonA = jsonA.add(factory.createObjectBuilder()
                   .add("code", res.getString("code"))
                   .add("name", res.getString("name"))
                   .add("address", res.getString("address"))
                   
                      );
                    
            }
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
    
    @POST
	@Path("/add")
	public Response addUser(
		@FormParam("name") String name,
		@FormParam("age") String age) {

		return Response.status(200)
			.entity("addUser is called, name : " + name + ", age : " + age)
			.build();

	}
  @GET
    @Path("eksetazomenou")
    @Produces(MediaType.APPLICATION_JSON)
    public String get_el_eksetazomenou() throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
            String sqlstring= "  select code,name,username from eksetazomenos;";

                    
            ResultSet res=myStatement.executeQuery(sqlstring);
            while(res.next()){
               jsonA = jsonA.add(factory.createObjectBuilder()
                   .add("code", res.getString("code"))
                   .add("name", res.getString("name"))
                   .add("username", res.getString("username"))
                   
                      );
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
    
    
    
      @GET
    @Path("res_by_choice/{code}")
    @Produces(MediaType.APPLICATION_JSON)
    public String get_el_eksetazomenou(@PathParam ("code") String code) throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
            String sqlstring= "  select eksetazomenos.name,eksetazomenos.username,questions.question, exet_erotiseis.apanthsh,questions.corr,exet_erotiseis.Time from exet_erotiseis,eksetazomenos,questions where exet_erotiseis.exetcode=eksetazomenos.code and exet_erotiseis.erotcode=questions.code and eksetazomenos.code='"+code+"';";
           
                    
            ResultSet res=myStatement.executeQuery(sqlstring);

          
            while(res.next()){
                
                if(res.getString("exet_erotiseis.apanthsh").equals(res.getString("questions.corr")))
                {
                        jsonA = jsonA.add(factory.createObjectBuilder()
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("time", res.getString("exet_erotiseis.Time"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false", "true")
                               );
                }
                else
                {
                     jsonA = jsonA.add(factory.createObjectBuilder()
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("time", res.getString("exet_erotiseis.Time"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "false")
                               );
                }
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }

    
    
    
    
      @GET
    @Path("res_by_date")
    @Produces(MediaType.APPLICATION_JSON)
    public String res_by_date(@PathParam ("par1") String code) throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
            String sqlstring= "select eks_kentro.name,eksetasi.date,eksetazomenos.name,eksetazomenos.username,questions.question, exet_erotiseis.apanthsh,questions.corr from exet_erotiseis,eksetazomenos,questions,eksetasi,eks_kentro where exet_erotiseis.exetcode=eksetazomenos.code and exet_erotiseis.erotcode=questions.code and eksetazomenos.eksetasi_code=eksetasi.code and eksetasi.kentro_code=eks_kentro.code order by eks_kentro.code,eksetazomenos.code;";
            ResultSet res=myStatement.executeQuery(sqlstring);

          
            while(res.next()){
                
                if(res.getString("exet_erotiseis.apanthsh").equals(res.getString("questions.corr")))
                {
                       jsonA = jsonA.add(factory.createObjectBuilder()
                            .add("ekskentro_name", res.getString("eks_kentro.name"))
                            .add("date", res.getString("eksetasi.date"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "true")
                               );
                }
                else
                {
                     jsonA = jsonA.add(factory.createObjectBuilder()
                            .add("ekskentro_name", res.getString("eks_kentro.name"))
                            .add("date", res.getString("eksetasi.date"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "false")
                               );
                }     
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
    
    
    
          @GET
    @Path("res_by_eksetasi")
    @Produces(MediaType.APPLICATION_JSON)
    public String res_by_eksetasi() throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
            String sqlstring= "select eksetasi.code,eksetasi.date,eksetasi.time,eksetazomenos.name,eksetazomenos.username,questions.question, exet_erotiseis.apanthsh,questions.corr from exet_erotiseis,eksetazomenos,questions,eksetasi,eks_kentro where exet_erotiseis.exetcode=eksetazomenos.code and exet_erotiseis.erotcode=questions.code and eksetazomenos.eksetasi_code=eksetasi.code and eksetasi.kentro_code=eks_kentro.code order by eksetasi.code,eksetazomenos.code;\n" +
                    ";";
            ResultSet res=myStatement.executeQuery(sqlstring);

          
            while(res.next()){
                
                if(res.getString("exet_erotiseis.apanthsh").equals(res.getString("questions.corr")))
                {
                       jsonA = jsonA.add(factory.createObjectBuilder()
                           .add("eksetasi_time", res.getString("eksetasi.time"))
                            .add("eksetasi_code", res.getString("eksetasi.code"))
                            .add("date", res.getString("eksetasi.date"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "true")
                               );
                }
                else
                {
                     jsonA = jsonA.add(factory.createObjectBuilder()
                             .add("eksetasi_time", res.getString("eksetasi.time"))
                            .add("eksetasi_code", res.getString("eksetasi.code"))
                            .add("date", res.getString("eksetasi.date"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "false")
                               );
                }     
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
    
    
    
    
              @GET
    @Path("res_by_kodiko")
    @Produces(MediaType.APPLICATION_JSON)
    public String res_by_kodiko() throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
           String sqlstring= "select eksetazomenos.code,eksetazomenos.name,eksetazomenos.username,questions.question, exet_erotiseis.apanthsh,questions.corr from exet_erotiseis,eksetazomenos,questions where  exet_erotiseis.exetcode=eksetazomenos.code and exet_erotiseis.erotcode=questions.code order by eksetazomenos.code ;";
            ResultSet res=myStatement.executeQuery(sqlstring);

          
            while(res.next()){
                
                if(res.getString("exet_erotiseis.apanthsh").equals(res.getString("questions.corr")))
                {
                       jsonA = jsonA.add(factory.createObjectBuilder()
                             .add("code", res.getString("eksetazomenos.code"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "true")
                               );
                }
                else
                {
                     jsonA = jsonA.add(factory.createObjectBuilder()
                             .add("code", res.getString("eksetazomenos.code"))
                            .add("name", res.getString("eksetazomenos.name"))
                            .add("username", res.getString("eksetazomenos.username"))
                            .add("question", res.getString("questions.question"))
                            .add("answer", res.getString("exet_erotiseis.apanthsh"))
                            .add("correct", res.getString("questions.corr")) 
                            .add("true_false",  "false")
                               );
                }     
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
    
    @GET
    @Path("specific_exam/{par11}")
    @Produces(MediaType.APPLICATION_JSON)
    public String spercific_exam(@PathParam ("par11") String code) throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
           String sqlstring= "select * from eksetasi where kentro_code='"+code+"' and flag='0'";
            ResultSet res=myStatement.executeQuery(sqlstring);

            while(res.next()){
                
             
                
                       jsonA = jsonA.add(factory.createObjectBuilder()
                             .add("code", res.getString("code"))
                            .add("date", res.getString("date"))
                            .add("time", res.getString("time"))
                             
                               );
               
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
        @GET
    @Path("specific_exam1/{par12}")
    @Produces(MediaType.APPLICATION_JSON)
    public String spercific_exam1(@PathParam ("par12") String code) throws ClassNotFoundException, SQLException  {
        
        
        
     
            Class.forName("com.mysql.jdbc.Driver");
           
             String myDatabase = "jdbc:mysql://localhost:3306/diktiakos?useUnicode=true&characterEncoding=utf-8&user=root";
            
            Connection myConnection = DriverManager.getConnection(myDatabase);
            
            Statement myStatement = myConnection.createStatement();
            if(!myConnection.isClosed()){//out.println("Successfully connected to " + "MySQL server using TCP/IP...");
                
            }
             JsonBuilderFactory factory = Json.createBuilderFactory(null);
             JsonObjectBuilder jsonB = factory.createObjectBuilder();
             JsonArrayBuilder jsonA = factory.createArrayBuilder();
           String sqlstring= "select * from eksetasi where kentro_code='"+code+"' ";
            ResultSet res=myStatement.executeQuery(sqlstring);

            while(res.next()){
                
             
                
                       jsonA = jsonA.add(factory.createObjectBuilder()
                             .add("code", res.getString("code"))
                            .add("date", res.getString("date"))
                            .add("time", res.getString("time"))
                             
                               );
               
            }
          
             
        //jsonB = jsonB.add("resposible", jsonA);
        myStatement.close();
        myConnection.close();
        return jsonA.build().toString();
            
    }
}
 
 


 
        